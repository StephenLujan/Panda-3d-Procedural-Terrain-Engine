# To change this template, choose Tools | Templates
# and open the template in the editor.

__author__ = "Stephen"
__date__ = "$Oct 27, 2010 4:47:05 AM$"

from panda3d.core import PNMImage
from panda3d.core import PerlinNoise2
from panda3d.core import Shader
from pandac.PandaModules import Filename
from pandac.PandaModules import GeoMipTerrain
from pandac.PandaModules import Point3
from pandac.PandaModules import TexGenAttrib
from pandac.PandaModules import Texture
from pandac.PandaModules import TextureStage
from pandac.PandaModules import Vec3
from pandac.PandaModules import Vec4

###############################################################################
#   HeightMapTile
###############################################################################

class HeightMapTile(GeoMipTerrain):

    def __init__(self, name):
        """Constructor should take a lot more parameters in the future."""

        GeoMipTerrain.__init__(self, name)

        self.mapName = "models/heightMap.png"
        self.image = PNMImage()
        self.maxHeight = 80
        self.size = 513
        self.consistency = 600
        self.smoothness = 120
        self.xOffset = 0
        self.yOffset = 0
        self.setBlockSize(16)

        #self.generateNoiseObjects()

    def generateNoiseObjects(self, seed=0):

        # where perlin 1 is low terrain will be mostly low and flat
        # where it is high terrain will be higher and slopes will be exagerrated
        # increase perlin1 to create larger areas of geographic consistency
        # increasing it too much on a small map may not work due normalization
        self.perlin1 = PerlinNoise2(self.size, self.size)
        self.perlin1.setScale(self.consistency)

        # perlin2 creates the noticeable noise in the terrain
        # without perlin2 everything would look unnaturally smooth and regular
        # increase perlin2 to make the terrain smoother
        self.perlin2 = PerlinNoise2(self.size, self.size)
        self.perlin2.setScale(self.smoothness)

    def update(self, dummy):
        GeoMipTerrain.update(self)

    def updateTask(self, task):
        self.update(task)
        return task.again

    def setHeightField(self, filename):
        GeoMipTerrain.setHeightfield(self, filename)

    def setHeight(self):
        """Set the heightfield to the the image file or generate a new one."""

        if (self.image.getXSize() < 1):
            self.image.read(Filename(self.mapName))
            if (self.image.getXSize() < 1):
                self.makeHeightMap()
                self.image.read(Filename(self.mapName))
        self.setHeightField(Filename(self.mapName))

    def getHeight(self, x, y):
        """Get the height at the specified world coordinates."""

        #height = (perlin1(x,y)*2 + perlin2(x,y) + 3.0)/6.0
        #height = (perlin1(x,y)/2 * perlin2(x,y)/2)+0.5
        return self.perlin1(x, y) + ((self.perlin1(x, y) + 1) * (self.perlin2(x, y) + 1))

    def makeHeightMap(self):
        """Generate a new heightmap image to use."""

        self.image = PNMImage(self.size, self.size)
        self.image.makeGrayscale()
        self.image.setNumChannels(1)
        self.image.setMaxval(65535)

        max = -9999.0
        min = 9999.0
        height = 0

        #return the minimum and maximum, useful to normalize the heightmap
        for x in range(self.xOffset, self.xOffset + self.image.getXSize()):
            for y in range(self.yOffset, self.yOffset + self.image.getYSize()):
                height = self.getHeight(x, y)
                if height < min:
                    min = height
                if height > max:
                    max = height

        #normalMax = -9999.0
        #normalMax = 9999.0

        for x in range(self.xOffset, self.xOffset + self.image.getXSize()):
            for y in range(self.yOffset, self.yOffset + self.image.getYSize()):
                height = self.getHeight(x, y)
                #normalize height
                height = (height - min) / (max-min)
                #feed pixel into image
                self.image.setGray(x, y, height)
                #this is just a test
                #if height < normalMin:
                #    normalMin = height
                #if height > normalMax:
                #    normalMax = height

        self.postProcessImage()

        print ("Prenomalized max = " + str(max))
        print ("Prenomalized min = " + str(min))
        self.image.write(Filename(self.mapName))

    def postProcessImage(self):
        """Perform filters and manipulations on the heightmap image."""

        #self.image.gaussianFilter()

    def wireframe(self):
        self.getRoot().setRenderModeWireframe()

    def make(self):
        """Build a finished renderable heightMap."""

        self.generateNoiseObjects()
        self.makeHeightMap()
        self.setHeight()
        self.getRoot().setSz(self.maxHeight)
        self.generate()

###############################################################################
#   TerrainTile
###############################################################################

class TerrainTile(HeightMapTile):
    def __init__(self, name):

        HeightMapTile.__init__(self, name)

        self.textureBlendMode = 7
        self.detailTexture = 0

    def setMonoTexture(self):
        """single texture"""

        root = self.getRoot()
        ts = TextureStage('ts')
        tex = loader.loadTexture("textures/rock.jpg")
        tex.setWrapU(Texture.WMMirror)
        tex.setWrapV(Texture.WMMirror)
        root.setTexture(ts, tex)
        root.setTexScale(ts, 10, 10)

    def setDetailBlendMode(self, num):
        """Set the blending mode of the detail texture."""

        if (not self.detailTexture):
            return
        self.textureBlendMode = num
        self.detailTexture.setMode(self.textureBlendMode)

    def incrementDetailBlendMode(self):
        """Set the blending mode of the detail texture."""

        if (not self.detailTexture):
            return
        self.textureBlendMode += 1
        self.detailTexture.setMode(self.textureBlendMode)

    def decrementDetailBlendMode(self):
        """Set the blending mode of the detail texture."""

        if (not self.detailTexture):
            return
        self.textureBlendMode -= 1
        self.detailTexture.setMode(self.textureBlendMode)

    def setDetailTexture(self):
        """texture + detail texture"""

        root = self.getRoot()

        ts = TextureStage('ts')
        tex = loader.loadTexture("textures/snow.jpg")
        tex.setWrapU(Texture.WMMirror)
        tex.setWrapV(Texture.WMMirror)
        root.setTexture(ts, tex)
        root.setTexScale(ts, 5, 5)

        self.detailTexture = TextureStage('ts2')
        tex = loader.loadTexture("textures/Detail.jpg")
        tex.setWrapU(Texture.WMMirror)
        tex.setWrapV(Texture.WMMirror)
        root.setTexture(self.detailTexture, tex)
        self.setDetailBlendMode(2)
        root.setTexScale(self.detailTexture, 120, 120)

    def setShader2(self):
        """Textures based on altitude. My own version"""

        root = self.getRoot()

        self.myShader = Shader.load('shaders/stephen2.sha', Shader.SLCg)
        root.setShader(self.myShader)

        root.setShaderInput('tscale', Vec4(16.0, 16.0, 16.0, 1.0))	# texture scaling

        blendArea = self.maxHeight * 0.11 + 0.5 #actually half the blend area
        transitionHeights = Vec3(12.0 + blendArea / 2, self.maxHeight * 0.52, self.maxHeight * 0.82)

        # regionLimits ( max height, min height, unused/extensible, unused/extensible )
        root.setShaderInput("region1Limits", Vec4(transitionHeights.getX() + blendArea, -999.0, 0, 0))
        root.setShaderInput("region2Limits", Vec4(transitionHeights.getY() + blendArea, transitionHeights.getX() - blendArea, 0, 0))
        root.setShaderInput("region3Limits", Vec4(transitionHeights.getZ() + blendArea, transitionHeights.getY() - blendArea, 0, 0))
        root.setShaderInput("region4Limits", Vec4(999.0, transitionHeights.getZ() - blendArea, 0, 0))

        #self.tex0 = loader.loadTexture(self.mapName)
        self.tex1 = loader.loadTexture("textures/dirt.jpg")
        #self.tex1.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex1.setMagfilter(Texture.FTLinear)
        self.tex2 = loader.loadTexture("textures/grass.jpg")
        #self.tex2.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex2.setMagfilter(Texture.FTLinear)
        self.tex3 = loader.loadTexture("textures/rock.jpg")
        #self.tex3.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex3.setMagfilter(Texture.FTLinear)
        self.tex4 = loader.loadTexture("textures/snow.jpg")
        #self.tex4.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex4.setMagfilter(Texture.FTLinear)

        ts = TextureStage('tex1')	# stage 0
        root.setTexture(ts, self.tex1)
        ts = TextureStage('tex2')	# stage 1
        root.setTexture(ts, self.tex2)
        ts = TextureStage('tex3')	# stage 2
        root.setTexture(ts, self.tex3)
        ts = TextureStage('tex4')	# stage 3
        root.setTexture(ts, self.tex4)

        #root.setShaderInput( "tex0", self.tex0 )
        root.setShaderInput("region1ColorMap", self.tex1)
        root.setShaderInput("region2ColorMap", self.tex2)
        root.setShaderInput("region3ColorMap", self.tex3)
        root.setShaderInput("region4ColorMap", self.tex4)

        # enable use of the two separate tagged render states for our two cameras
        root.setTag('Normal', 'True')
        root.setTag('Clipped', 'True')

        #self.shaderAttribute = ShaderAttrib.make( )
        #self.shaderAttribute = self.shaderAttribute.setShader(
        #loader.loadShader('shaders/stephen.sha'))


    def setShader4(self):
        """Textures based on altitude and slope. My own version. Normal data appears broken."""

        root = self.getRoot()

        self.myShader = Shader.load('shaders/stephen4.sha', Shader.SLCg)
        root.setShader(self.myShader)

        #self.tex0 = loader.loadTexture(self.mapName)
        self.tex1 = loader.loadTexture("textures/dirt.jpg")
        #self.tex1.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex1.setMagfilter(Texture.FTLinear)
        self.tex2 = loader.loadTexture("textures/grass.jpg")
        #self.tex2.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex2.setMagfilter(Texture.FTLinear)
        self.tex3 = loader.loadTexture("textures/rock.jpg")
        #self.tex3.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex3.setMagfilter(Texture.FTLinear)
        self.tex4 = loader.loadTexture("textures/snow.jpg")
        #self.tex4.setMinfilter(Texture.FTNearestMipmapLinear)
        #self.tex4.setMagfilter(Texture.FTLinear)

        ts = TextureStage('tex1')	# stage 0
        root.setTexture(ts, self.tex1)
        ts = TextureStage('tex2')	# stage 1
        root.setTexture(ts, self.tex2)
        ts = TextureStage('tex3')	# stage 2
        root.setTexture(ts, self.tex3)
        ts = TextureStage('tex4')	# stage 3
        root.setTexture(ts, self.tex4)

        #root.setShaderInput( "tex0", self.tex0 )
        root.setShaderInput("region1ColorMap", self.tex1)
        root.setShaderInput("region2ColorMap", self.tex2)
        root.setShaderInput("region3ColorMap", self.tex3)
        root.setShaderInput("region4ColorMap", self.tex4)

        root.setShaderInput('tscale', Vec4(16.0, 16.0, 16.0, 1.0))	# texture scaling

        blendArea = self.maxHeight * 0.11 + 0.5
        # Limits (height max, height min, slope max, slope min)
#        root.setShaderInput("region1Limits", Vec4(15.0, -999.0, 0.5, 0.0))
#        root.setShaderInput("region2Limits", Vec4(self.maxHeight* 0.65, 10.00, 0.5, 0.0))
#        root.setShaderInput("region3Limits", Vec4(self.maxHeight* 0.85, 15.0, 1.0, 0.4))
#        root.setShaderInput("region4Limits", Vec4(999.0, self.maxHeight* 0.75, 1.0, 0.0))
        root.setShaderInput("region1Limits", Vec4(12 + blendArea, -999.0, 0.6, 0.0))
        root.setShaderInput("region2Limits", Vec4(self.maxHeight * 0.65, 10, 0.6, 0.0))
        root.setShaderInput("region3Limits", Vec4(self.maxHeight * 0.8 + blendArea, 12.0, 1.0, 0.3))
        root.setShaderInput("region4Limits", Vec4(999.0, self.maxHeight * 0.8 - blendArea, 1.0, 0.0))

        # enable use of the two separate tagged render states for our two cameras
        root.setTag('Normal', 'True')
        root.setTag('Clipped', 'True')
        #self.shaderAttribute = ShaderAttrib.make( )
        #self.shaderAttribute = self.shaderAttribute.setShader(
        #loader.loadShader('shaders/stephen2.sha'))

    def setMultiTexture(self):
        """Set up the appropriate shader for multi texture terrain."""
        self.setShader2()

    def make(self):

        HeightMapTile.make(self)
        #self.setMultiTexture()
